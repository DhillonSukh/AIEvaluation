# GeminiAiAssistantApiSwagger

A .NET 8 learning project demonstrating a Gemini-backed API, embeddings, in-memory vector search, and a simple RAG pipeline.

## Requirements
- .NET 8 SDK
- Google AI Studio API key
- Internet access for Gemini API requests

## Configure the API key

PowerShell (current terminal only):

```powershell
$env:GEMINI_API_KEY = "YOUR_API_KEY"
dotnet restore
dotnet build
dotnet run
```

Command Prompt:

```bat
set GEMINI_API_KEY=YOUR_API_KEY
dotnet restore
dotnet build
dotnet run
```

Use your actual key locally. Do not commit it to source control or paste it into source files.

## Swagger
Open the Swagger URL printed by `dotnet run`. In Development, Swagger UI is enabled.

## Test RAG
First call `POST /api/rag/index` with:

```json
{
  "documentId": "returns-policy-v1",
  "source": "Returns Policy v1",
  "text": "Customers may request a refund for damaged products within 30 days of delivery. Proof of purchase is required. Products damaged through customer misuse are not eligible for a refund."
}
```

Then call `POST /api/rag/ask` with:

```json
{
  "question": "Can I get a refund if my product arrived damaged?"
}
```

You should get an answer and a list of retrieved sources.

## Other endpoint
`POST /api/ask` sends a general question to Gemini without retrieval.

## Learning limitations
- The vector index is in memory and resets when the application restarts.
- The sample order tool is a stub and is not exposed as model-controlled function calling in this starter project.
- This is a learning project, not production-ready. Add authentication, authorization, rate limiting, resilient retries, safe error handling, persistent vector storage, document access filtering, and monitoring before deployment.
- Gemini is used for learning. It is not Microsoft Azure AI Foundry; later study should map these concepts to Azure equivalents.


## Day 7: RAG evaluation

This update adds:
- `SearchWithScores` to preserve similarity scores.
- Optional source metadata filtering before similarity ranking.
- A `0.50` provisional relevance threshold in `RagService`.
- `POST /api/rag/evaluate` to test expected-source retrieval and optional generated-answer smoke checks.
- Similarity scores and retrieved passages in the `/api/rag/ask` response.

### 1. Index test documents
Call `POST /api/rag/index` at least twice with different source names. Example:

```json
{
  "documentId": "refund-policy-v1",
  "source": "RefundPolicy.pdf",
  "text": "Damaged products may be eligible for a refund. Customers should provide proof of purchase and contact customer support for assessment."
}
```

Index another document using source `AnnualLeavePolicy.pdf` with leave-policy text. Remember the vector index is in memory; index documents again after restarting the app.

### 2. Run evaluation
Call `POST /api/rag/evaluate`:

```json
{
  "evaluateGeneratedAnswers": true,
  "cases": [
    {
      "question": "Can I get a refund for a damaged product?",
      "expectedSource": "RefundPolicy.pdf",
      "prohibitedClaims": ["all damaged products receive a full refund within 30 days"]
    },
    {
      "question": "What is the annual leave policy?",
      "expectedSource": "AnnualLeavePolicy.pdf"
    }
  ]
}
```

`retrievalHitRate` is the proportion of test cases where the expected source appears in the retrieved results. `answerPassRate` is the proportion of generated answers that pass the explicit smoke checks supplied in each case. If you want to avoid model-generation calls, set `evaluateGeneratedAnswers` to `false`.

You can test Day 6 source filtering by adding `"sourceFilter": "RefundPolicy.pdf"` to a case. A filter intentionally restricts which sources are eligible; don't set it on general questions unless the application requirement calls for that restriction.

### Evaluation limitations
- The `0.50` similarity threshold is a starting value, not a universal relevance boundary.
- Source hit rate is a basic metric, not full precision/recall or complete retrieval evaluation.
- Prohibited-claim and required-term checks are deterministic smoke tests, not a general-purpose hallucination detector or semantic judge.
- To evaluate answer quality more fully, use curated reference answers and evidence, human review, or a validated model-assisted evaluator.
- `evaluateGeneratedAnswers: true` may call Gemini once per test case that has relevant retrieved passages, so it uses API quota.
- This project is for learning, not production. The index is in memory, and the sample does not implement production authentication, authorization, rate limiting, telemetry, or robust evaluation orchestration.
