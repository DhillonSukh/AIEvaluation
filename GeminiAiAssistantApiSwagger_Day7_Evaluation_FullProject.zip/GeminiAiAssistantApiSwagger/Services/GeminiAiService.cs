using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace GeminiAiAssistantApiSwagger.Services;

public sealed class GeminiAiService : IAiService
{
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _configuration;

    public GeminiAiService(HttpClient httpClient, IConfiguration configuration)
    {
        _httpClient = httpClient;
        _configuration = configuration;
        _httpClient.BaseAddress = new Uri(
            _configuration["Gemini:ApiBaseUrl"] ?? "https://generativelanguage.googleapis.com/v1beta/");
    }

    public async Task<string> AskAsync(string question, CancellationToken cancellationToken = default)
    {
        var apiKey = Environment.GetEnvironmentVariable("GEMINI_API_KEY");
        if (string.IsNullOrWhiteSpace(apiKey))
            throw new InvalidOperationException("Set the GEMINI_API_KEY environment variable before calling Gemini.");

        var model = _configuration["Gemini:Model"] ?? "gemini-2.5-flash";
        var payload = new
        {
            contents = new[]
            {
                new { role = "user", parts = new[] { new { text = question } } }
            },
            generationConfig = new { temperature = 0.2 }
        };

        using var request = new HttpRequestMessage(
            HttpMethod.Post, $"models/{model}:generateContent?key={Uri.EscapeDataString(apiKey)}");
        request.Content = new StringContent(
            JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);
        if (!response.IsSuccessStatusCode)
            throw new HttpRequestException($"Gemini request failed ({(int)response.StatusCode}): {body}");

        using var document = JsonDocument.Parse(body);
        if (document.RootElement.TryGetProperty("candidates", out var candidates) &&
            candidates.GetArrayLength() > 0 &&
            candidates[0].TryGetProperty("content", out var content) &&
            content.TryGetProperty("parts", out var parts))
        {
            var answer = string.Join("", parts.EnumerateArray()
                .Where(p => p.TryGetProperty("text", out _))
                .Select(p => p.GetProperty("text").GetString()));
            if (!string.IsNullOrWhiteSpace(answer))
                return answer;
        }

        throw new InvalidOperationException("Gemini returned no text answer.");
    }
}
