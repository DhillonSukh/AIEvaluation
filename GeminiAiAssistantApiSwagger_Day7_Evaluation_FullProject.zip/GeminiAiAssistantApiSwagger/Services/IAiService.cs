namespace GeminiAiAssistantApiSwagger.Services;

public interface IAiService
{
    Task<string> AskAsync(string question, CancellationToken cancellationToken = default);
}
