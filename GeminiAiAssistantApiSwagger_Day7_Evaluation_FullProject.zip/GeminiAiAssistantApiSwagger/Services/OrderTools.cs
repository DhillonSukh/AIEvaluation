namespace GeminiAiAssistantApiSwagger.Services;

public sealed class OrderTools
{
    public object GetOrderStatus(string orderId) => orderId switch
    {
        "ORD-1001" => new { OrderId = orderId, Status = "Shipped", TrackingNumber = "TRACK-12345", ExpectedDelivery = "2026-10-25" },
        "ORD-1002" => new { OrderId = orderId, Status = "Processing", TrackingNumber = (string?)null, ExpectedDelivery = (string?)null },
        _ => new { OrderId = orderId, Status = "NotFound", TrackingNumber = (string?)null, ExpectedDelivery = (string?)null }
    };
}
