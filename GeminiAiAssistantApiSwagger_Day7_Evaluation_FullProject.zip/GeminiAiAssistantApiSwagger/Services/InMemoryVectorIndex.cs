namespace GeminiAiAssistantApiSwagger.Services;

public sealed class InMemoryVectorIndex
{
    private readonly object _lock = new();
    private readonly List<IndexedChunk> _chunks = new();

    public void Add(IndexedChunk chunk)
    {
        lock (_lock)
        {
            _chunks.RemoveAll(existing => existing.Id == chunk.Id);
            _chunks.Add(chunk);
        }
    }

    // Day 4-compatible method: returns chunks only.
    public IReadOnlyList<IndexedChunk> Search(float[] queryEmbedding, int topK = 3)
    {
        return SearchWithScores(queryEmbedding, source: null, topK: topK)
            .Select(result => result.Chunk)
            .ToArray();
    }

    // Day 5: keep the similarity score. Day 6: optionally filter by source before ranking.
    public IReadOnlyList<VectorSearchResult> SearchWithScores(
        float[] queryEmbedding,
        string? source = null,
        int topK = 3)
    {
        lock (_lock)
        {
            IEnumerable<IndexedChunk> candidates = _chunks;

            if (!string.IsNullOrWhiteSpace(source))
            {
                candidates = candidates.Where(chunk =>
                    string.Equals(
                        chunk.Source,
                        source,
                        StringComparison.OrdinalIgnoreCase));
            }

            return candidates
                .Select(chunk => new VectorSearchResult(
                    chunk,
                    CosineSimilarity(queryEmbedding, chunk.Embedding)))
                .OrderByDescending(result => result.Score)
                .Take(Math.Max(0, topK))
                .ToArray();
        }
    }

    private static float CosineSimilarity(float[] a, float[] b)
    {
        if (a.Length != b.Length)
            throw new ArgumentException("Embedding dimensions do not match.");

        double dot = 0, normA = 0, normB = 0;
        for (var i = 0; i < a.Length; i++)
        {
            dot += a[i] * b[i];
            normA += a[i] * a[i];
            normB += b[i] * b[i];
        }

        if (normA == 0 || normB == 0)
            return 0;

        return (float)(dot / (Math.Sqrt(normA) * Math.Sqrt(normB)));
    }
}
