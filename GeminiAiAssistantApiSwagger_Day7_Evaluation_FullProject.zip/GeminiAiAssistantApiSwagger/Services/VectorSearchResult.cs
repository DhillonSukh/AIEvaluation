namespace GeminiAiAssistantApiSwagger.Services;

public sealed record VectorSearchResult(
    IndexedChunk Chunk,
    float Score);
