using System.Text;
using System.Text.Json;

namespace GeminiAiAssistantApiSwagger.Services;

public sealed class EmbeddingService
{
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _configuration;

    public EmbeddingService(HttpClient httpClient, IConfiguration configuration)
    {
        _httpClient = httpClient;
        _configuration = configuration;
        _httpClient.BaseAddress = new Uri(
            _configuration["Gemini:ApiBaseUrl"] ?? "https://generativelanguage.googleapis.com/v1beta/");
    }

    public async Task<float[]> EmbedAsync(
        string text, CancellationToken cancellationToken = default)
    {
        var apiKey = Environment.GetEnvironmentVariable("GEMINI_API_KEY");
        if (string.IsNullOrWhiteSpace(apiKey))
            throw new InvalidOperationException("Set the GEMINI_API_KEY environment variable before creating embeddings.");

        var model = _configuration["Gemini:EmbeddingModel"] ?? "gemini-embedding-001";
        var payload = new
        {
            model = $"models/{model}",
            content = new { parts = new[] { new { text } } }
        };

        using var request = new HttpRequestMessage(
            HttpMethod.Post, $"models/{model}:embedContent?key={Uri.EscapeDataString(apiKey)}");
        request.Content = new StringContent(
            JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);
        if (!response.IsSuccessStatusCode)
            throw new HttpRequestException($"Gemini embedding request failed ({(int)response.StatusCode}): {body}");

        using var document = JsonDocument.Parse(body);
        var values = document.RootElement
            .GetProperty("embedding")
            .GetProperty("values");

        return values.EnumerateArray().Select(v => v.GetSingle()).ToArray();
    }
}
