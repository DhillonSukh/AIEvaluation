namespace GeminiAiAssistantApiSwagger.Services;

public sealed record IndexedChunk(
    string Id,
    string Text,
    float[] Embedding,
    string Source);
