using GeminiAiAssistantApiSwagger.Models;

namespace GeminiAiAssistantApiSwagger.Services;

public sealed class RagEvaluationService
{
    private readonly RagService _ragService;

    public RagEvaluationService(RagService ragService)
    {
        _ragService = ragService;
    }

    public async Task<RagEvaluationResponse> EvaluateAsync(
        RagEvaluationRequest request,
        CancellationToken cancellationToken = default)
    {
        if (request.Cases.Count == 0)
            throw new ArgumentException("At least one evaluation case is required.");

        var results = new List<RagEvaluationCaseResult>();

        foreach (var testCase in request.Cases)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var retrieval = await _ragService.RetrieveAsync(
                testCase.Question,
                testCase.SourceFilter,
                topK: 3,
                cancellationToken);

            var retrievedSources = retrieval.Matches
                .Select(match => match.Chunk.Source)
                .Where(source => !string.IsNullOrWhiteSpace(source))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();

            var retrievalPassed = retrievedSources.Contains(
                testCase.ExpectedSource,
                StringComparer.OrdinalIgnoreCase);

            string? answer = null;
            bool answerEvaluated = false;
            bool? answerPassed = null;
            var failures = new List<string>();

            if (request.EvaluateGeneratedAnswers)
            {
                answerEvaluated = true;
                if (retrieval.Matches.Count == 0)
                {
                    answer = "I couldn't find sufficiently relevant information in the indexed documents to answer this question.";
                }
                else
                {
                    answer = await _ragService.GenerateAnswerAsync(
                        testCase.Question, retrieval, cancellationToken);
                }

                if (string.IsNullOrWhiteSpace(answer))
                    failures.Add("The generated answer was empty.");

                foreach (var prohibitedClaim in testCase.ProhibitedClaims.Where(
                             claim => !string.IsNullOrWhiteSpace(claim)))
                {
                    if (answer.Contains(prohibitedClaim, StringComparison.OrdinalIgnoreCase))
                        failures.Add($"Answer contained a prohibited claim: '{prohibitedClaim}'.");
                }

                foreach (var requiredTerm in testCase.RequiredAnswerTerms.Where(
                             term => !string.IsNullOrWhiteSpace(term)))
                {
                    if (!answer.Contains(requiredTerm, StringComparison.OrdinalIgnoreCase))
                        failures.Add($"Answer did not contain expected term: '{requiredTerm}'.");
                }

                answerPassed = failures.Count == 0;
            }

            results.Add(new RagEvaluationCaseResult(
                testCase.Question,
                testCase.ExpectedSource,
                retrievedSources,
                retrieval.Matches.Select(match => new RetrievedChunkResult(
                    match.Chunk.Source, match.Score, match.Chunk.Text)).ToArray(),
                retrievalPassed,
                answerEvaluated,
                answerPassed,
                failures.ToArray(),
                answer));
        }

        var retrievalPassedCount = results.Count(result => result.RetrievalPassed);
        var answerEvaluatedResults = results.Where(result => result.AnswerEvaluated).ToArray();
        var answerPassedCount = answerEvaluatedResults.Count(result => result.AnswerPassed == true);

        return new RagEvaluationResponse(
            results.Count,
            retrievalPassedCount,
            results.Count == 0 ? 0 : (double)retrievalPassedCount / results.Count,
            answerEvaluatedResults.Length,
            answerPassedCount,
            answerEvaluatedResults.Length == 0
                ? null
                : (double)answerPassedCount / answerEvaluatedResults.Length,
            results);
    }
}
