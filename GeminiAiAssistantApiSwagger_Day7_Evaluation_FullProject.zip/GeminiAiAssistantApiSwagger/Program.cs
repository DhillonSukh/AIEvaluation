using GeminiAiAssistantApiSwagger.Services;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Gemini AI Assistant API",
        Version = "v1",
        Description = "Learning project: Gemini function calling and in-memory RAG."
    });
});

builder.Services.AddHttpClient<GeminiAiService>();
builder.Services.AddHttpClient<EmbeddingService>();
builder.Services.AddScoped<IAiService>(sp => sp.GetRequiredService<GeminiAiService>());
builder.Services.AddSingleton<OrderTools>();
builder.Services.AddSingleton<InMemoryVectorIndex>();
builder.Services.AddScoped<RagService>();
builder.Services.AddScoped<RagEvaluationService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.MapControllers();
app.Run();
