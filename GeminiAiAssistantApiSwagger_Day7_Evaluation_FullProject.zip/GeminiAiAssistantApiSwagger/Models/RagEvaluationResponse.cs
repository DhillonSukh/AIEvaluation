namespace GeminiAiAssistantApiSwagger.Models;

public sealed record RagEvaluationResponse(
    int TotalCases,
    int RetrievalPassed,
    double RetrievalHitRate,
    int AnswerEvaluated,
    int AnswerPassed,
    double? AnswerPassRate,
    IReadOnlyList<RagEvaluationCaseResult> Results);

public sealed record RagEvaluationCaseResult(
    string Question,
    string ExpectedSource,
    string[] RetrievedSources,
    IReadOnlyList<RetrievedChunkResult> RetrievedChunks,
    bool RetrievalPassed,
    bool AnswerEvaluated,
    bool? AnswerPassed,
    string[] AnswerFailureReasons,
    string? Answer);

public sealed record RetrievedChunkResult(
    string Source,
    float Similarity,
    string Text);
