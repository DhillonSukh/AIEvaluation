using System.ComponentModel.DataAnnotations;

namespace GeminiAiAssistantApiSwagger.Models;

public sealed record AskRequest(
    [property: Required]
    [property: StringLength(4000, MinimumLength = 1)]
    string Question);
