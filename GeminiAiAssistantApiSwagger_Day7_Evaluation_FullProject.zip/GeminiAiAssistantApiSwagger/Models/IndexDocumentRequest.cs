using System.ComponentModel.DataAnnotations;

namespace GeminiAiAssistantApiSwagger.Models;

public sealed record IndexDocumentRequest(
    [property: Required, StringLength(100, MinimumLength = 1)] string DocumentId,
    [property: Required, StringLength(200, MinimumLength = 1)] string Source,
    [property: Required, StringLength(50000, MinimumLength = 1)] string Text);
