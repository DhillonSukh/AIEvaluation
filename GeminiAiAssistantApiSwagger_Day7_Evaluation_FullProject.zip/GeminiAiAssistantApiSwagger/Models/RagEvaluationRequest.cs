using System.ComponentModel.DataAnnotations;

namespace GeminiAiAssistantApiSwagger.Models;

public sealed class RagEvaluationRequest
{
    [Required, MinLength(1), MaxLength(30)]
    public List<RagEvaluationCase> Cases { get; init; } = [];

    // This calls the model for each case that has relevant retrieved passages.
    // Set false to test retrieval only and avoid generation calls.
    public bool EvaluateGeneratedAnswers { get; init; } = true;
}

public sealed class RagEvaluationCase
{
    [Required, StringLength(2000, MinimumLength = 1)]
    public string Question { get; init; } = string.Empty;

    [Required, StringLength(200, MinimumLength = 1)]
    public string ExpectedSource { get; init; } = string.Empty;

    // Optional exact source filter, useful for checking Day 6 metadata filtering.
    public string? SourceFilter { get; init; }

    // Deterministic smoke checks only; they are not a general hallucination detector.
    public string[] ProhibitedClaims { get; init; } = [];

    // If supplied, every term must appear in the generated answer (case-insensitive).
    // Use sparingly because wording can vary.
    public string[] RequiredAnswerTerms { get; init; } = [];
}
