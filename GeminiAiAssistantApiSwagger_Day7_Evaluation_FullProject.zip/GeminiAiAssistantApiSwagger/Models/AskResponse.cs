namespace GeminiAiAssistantApiSwagger.Models;

public sealed record AskResponse(string Answer);
