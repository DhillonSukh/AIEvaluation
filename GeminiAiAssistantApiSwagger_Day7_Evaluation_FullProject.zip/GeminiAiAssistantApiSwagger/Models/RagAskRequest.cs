using System.ComponentModel.DataAnnotations;

namespace GeminiAiAssistantApiSwagger.Models;

public sealed record RagAskRequest(
    [property: Required, StringLength(2000, MinimumLength = 1)] string Question);
