using GeminiAiAssistantApiSwagger.Models;
using GeminiAiAssistantApiSwagger.Services;
using Microsoft.AspNetCore.Mvc;

namespace GeminiAiAssistantApiSwagger.Controllers;

[ApiController]
[Route("api/[controller]")]
public sealed class AskController : ControllerBase
{
    private readonly IAiService _aiService;

    public AskController(IAiService aiService) => _aiService = aiService;

    [HttpPost]
    [ProducesResponseType(typeof(AskResponse), StatusCodes.Status200OK)]
    public async Task<ActionResult<AskResponse>> Ask(
        [FromBody] AskRequest request, CancellationToken cancellationToken)
    {
        var answer = await _aiService.AskAsync(request.Question, cancellationToken);
        return Ok(new AskResponse(answer));
    }
}
