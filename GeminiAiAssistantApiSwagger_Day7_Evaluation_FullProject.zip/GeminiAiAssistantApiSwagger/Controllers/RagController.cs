using GeminiAiAssistantApiSwagger.Models;
using GeminiAiAssistantApiSwagger.Services;
using Microsoft.AspNetCore.Mvc;

namespace GeminiAiAssistantApiSwagger.Controllers;

[ApiController]
[Route("api/rag")]
public sealed class RagController : ControllerBase
{
    private readonly RagService _ragService;
    private readonly RagEvaluationService _evaluationService;

    public RagController(RagService ragService, RagEvaluationService evaluationService)
    {
        _ragService = ragService;
        _evaluationService = evaluationService;
    }

    [HttpPost("index")]
    public async Task<IActionResult> Index(
        [FromBody] IndexDocumentRequest request,
        CancellationToken cancellationToken)
    {
        var count = await _ragService.IndexDocumentAsync(
            request.DocumentId, request.Source, request.Text, cancellationToken);

        return Ok(new { Message = "Document indexed.", ChunkCount = count });
    }

    [HttpPost("ask")]
    public async Task<IActionResult> Ask(
        [FromBody] RagAskRequest request,
        CancellationToken cancellationToken)
    {
        var result = await _ragService.AskDetailedAsync(
            request.Question, cancellationToken: cancellationToken);

        return Ok(new
        {
            result.Answer,
            result.Sources,
            MinimumSimilarity = result.MinimumSimilarity,
            RetrievedChunks = result.Matches.Select(match => new
            {
                match.Chunk.Source,
                match.Score,
                match.Chunk.Text
            })
        });
    }

    [HttpPost("evaluate")]
    public async Task<ActionResult<RagEvaluationResponse>> Evaluate(
        [FromBody] RagEvaluationRequest request,
        CancellationToken cancellationToken)
    {
        var result = await _evaluationService.EvaluateAsync(request, cancellationToken);
        return Ok(result);
    }
}
